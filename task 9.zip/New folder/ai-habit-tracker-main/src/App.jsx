import React, { useState, useEffect, useRef } from 'react';
// Firebase Imports
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInAnonymously,
  signInWithCustomToken,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  addDoc,
  updateDoc,
  onSnapshot,
  query,
  deleteDoc,
  setLogLevel,
} from 'firebase/firestore';

// ==========================================================
// --- ENVIRONMENT HANDLING AND LOCAL CONFIGURATION (REQUIRED FOR LOCAL USE) ---
// If you are running this code locally, you MUST replace the placeholder values below 
// with your actual Firebase project configuration for the app to work.
// NOTE: When deployed to the Canvas, this block is ignored, and global variables are used.

const LOCAL_FIREBASE_CONFIG = {
  // 🚨🚨 CRITICAL: REPLACE THESE THREE VALUES WITH YOUR FIREBASE PROJECT CONFIG 🚨🚨
  apiKey: "*****", // <-- MUST BE REPLACED
  authDomain: "****", 
  projectId: "***", // <-- MUST BE REPLACED
  // Other config details can typically remain if they match the Project ID structure
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef1234567890",
};
const LOCAL_APP_ID = 'local-habit-tracker-v1'; // Local identifier
const LOCAL_AUTH_TOKEN = null; // Use null for local anonymous sign-in

// --- NEW: GEMINI API KEY FOR LOCAL RUNS ---
// 🚨🚨 CRITICAL: GET YOUR KEY AND REPLACE THIS PLACEHOLDER 🚨🚨
const LOCAL_GEMINI_API_KEY = "****"; 


// --- Determine Configuration Source ---
const IS_LOCAL_ENV = typeof __firebase_config === 'undefined';

const FIREBASE_CONFIG = IS_LOCAL_ENV 
  ? LOCAL_FIREBASE_CONFIG 
  : JSON.parse(__firebase_config);

const APP_ID = IS_LOCAL_ENV 
  ? LOCAL_APP_ID 
  : typeof __app_id !== 'undefined' ? __app_id : LOCAL_APP_ID;

const INITIAL_AUTH_TOKEN = IS_LOCAL_ENV 
  ? LOCAL_AUTH_TOKEN 
  : typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : LOCAL_AUTH_TOKEN;

// --- API Configuration ---
const BASE_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent';
const API_URL = IS_LOCAL_ENV 
  ? `${BASE_API_URL}?key=${LOCAL_GEMINI_API_KEY}`
  : BASE_API_URL; // Canvas handles key injection when not local

// --- Web Component Fallbacks for React Native (Unchanged) ---
const View = ({ style, ...props }) => (
  <div style={style} {...props}>
    {props.children}
  </div>
);

const Text = ({ style, ...props }) => (
  <span style={style} {...props}>
    {props.children}
  </span>
);

const TextInput = ({ style, placeholder, value, onChangeText, placeholderTextColor }) => (
  <input
    style={{...style, "::placeholder": { color: placeholderTextColor }}} 
    placeholder={placeholder}
    value={value}
    onChange={(e) => onChangeText(e.target.value)}
  />
);

const TouchableOpacity = ({ style, onPress, disabled, children }) => (
  <button style={style} onClick={onPress} disabled={disabled}>
    {children}
  </button>
);

const FlatList = ({ data, renderItem, keyExtractor, ListEmptyComponent, style }) => {
  if (!data || data.length === 0) {
    return ListEmptyComponent ? ListEmptyComponent : null;
  }
  return (
    <div style={{...styles.list, ...style}}>
      {data.map((item) => (
        <div key={keyExtractor(item)}>
          {renderItem({ item })}
        </div>
      ))}
    </div>
  );
};

const SafeAreaView = ({ style, ...props }) => <div style={{...styles.container, ...style}} {...props} />;

const Modal = ({ visible, children }) => {
  if (!visible) return null;
  return (
    <div style={styles.modalContainer}>
      {children}
    </div>
  );
};

const ActivityIndicator = () => <Text style={{color: '#fff'}}>Loading...</Text>;

const Alert = {
  alert: (title, message) => {
    console.log(`ALERT - ${title}: ${message}`);
  },
};

const Keyboard = {
  dismiss: () => {
    if (document.activeElement) document.activeElement.blur();
  },
};
// --- End of Web Component Fallbacks ---


export default function App() {
  const [userId, setUserId] = useState(null);
  const [habits, setHabits] = useState([]);
  const [newHabit, setNewHabit] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [aiGoal, setAiGoal] = useState('');
  const [aiSuggestion, setAiSuggestion] = useState('');
  const [loadingAI, setLoadingAI] = useState(false);

  // State to hold the initialized Firebase services
  const [fbServices, setFbServices] = useState({ app: null, auth: null, db: null });

  // Reference to the habits collection
  const habitsCollectionRef = useRef(null);

  // --- Firebase Initialization and Authentication Effect ---
  useEffect(() => {
    let authSubscriber;
    
    const initializeFirebase = async () => {
      try {
        if (!FIREBASE_CONFIG.apiKey || !FIREBASE_CONFIG.projectId) {
          throw new Error("Firebase configuration is missing crucial details. Please check the LOCAL_FIREBASE_CONFIG block.");
        }
        
        // --- DEBUG: Log the config being used ---
        console.log("Using Firebase Config:", FIREBASE_CONFIG); 

        // 1. Initialize App
        const firebaseApp = initializeApp(FIREBASE_CONFIG);
        
        // 2. Initialize Services
        const firebaseAuth = getAuth(firebaseApp);
        const firestoreDb = getFirestore(firebaseApp);
        setLogLevel('debug');

        setFbServices({ app: firebaseApp, auth: firebaseAuth, db: firestoreDb });

        // 3. Handle Authentication
        if (INITIAL_AUTH_TOKEN) {
          console.log('Attempting sign-in with custom token...');
          await signInWithCustomToken(firebaseAuth, INITIAL_AUTH_TOKEN);
        } else {
          console.log('No custom token found. Signing in anonymously...');
          await signInAnonymously(firebaseAuth);
        }

        // 4. Set up Auth State Listener (Crucial for getting the UID)
        authSubscriber = onAuthStateChanged(firebaseAuth, (user) => {
          if (user) {
            console.log('User signed in. UID:', user.uid);
            setUserId(user.uid);
          } else {
            console.log('User signed out.');
            setUserId(null);
          }
        });

      } catch (error) {
        console.error('FATAL Firebase Initialization Error:', error.message);
        setUserId('Initialization Failed');
        // Give a more specific error message based on the config being used
        showCustomAlert('Init Error', `Firebase failed to initialize. Error: ${error.message}. Please check your console (F12) and ensure the configuration output is correct.`);
      }
    };
    
    initializeFirebase();

    return () => {
      if (authSubscriber) {
        authSubscriber();
      }
    };
  }, []); 

  // --- Firestore Data Listener Effect ---
  useEffect(() => {
    const { db } = fbServices;
    if (!userId || userId === 'Initialization Failed' || !db) {
      console.log('Waiting for user ID or DB initialization...');
      return;
    }

    console.log(`Setting up Firestore snapshot for user: ${userId}`);
    const collectionPath = `/artifacts/${APP_ID}/users/${userId}/habits`;
    habitsCollectionRef.current = collection(db, collectionPath);

    const q = query(habitsCollectionRef.current);

    const snapshotUnsubscribe = onSnapshot(
      q,
      (querySnapshot) => {
        console.log(`Received snapshot with ${querySnapshot.size} docs.`);
        const habitsList = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setHabits(habitsList);
        console.log('Habits state updated.');
      },
      (error) => {
        console.error('Error fetching habits snapshot:', error);
      }
    );

    return () => {
      console.log('Unsubscribing from Firestore snapshot.');
      snapshotUnsubscribe();
    };
  }, [userId, fbServices.db]); 

  // --- Add Habit Function ---
  const handleAddHabit = async (habitName) => {
    const name = habitName.trim();
    if (!name) {
      showCustomAlert('Empty Habit', 'Please enter a habit name.');
      return;
    }
    if (!habitsCollectionRef.current) {
      console.error('Habits collection ref is not set. Is Firebase initialized?');
      showCustomAlert('Connection Error', 'Please wait for connection to initialize.');
      return;
    }

    console.log(`Adding habit: ${name}`);
    try {
      await addDoc(habitsCollectionRef.current, {
        name: name,
        completed: false,
        date: new Date().toISOString().split('T')[0], 
      });
      setNewHabit('');
      setAiSuggestion('');
      setAiGoal('');
      setModalVisible(false);
      Keyboard.dismiss();
      console.log('Habit added successfully.');
    } catch (error) {
      console.error('Error adding habit:', error);
      showCustomAlert('Database Error', `Failed to add habit: ${error.message}`);
    }
  };

  // --- Toggle Habit Completion ---
  const toggleHabit = async (id, currentStatus) => {
    const { db } = fbServices;
    if (!userId || !db) return;

    console.log(`Toggling habit ${id} to ${!currentStatus}`);
    try {
      const habitDocRef = doc(db, `/artifacts/${APP_ID}/users/${userId}/habits`, id);
      await updateDoc(habitDocRef, {
        completed: !currentStatus,
      });
      console.log('Habit toggled successfully.');
    } catch (error)
    {
      console.error('Error toggling habit:', error);
      showCustomAlert('Database Error', `Failed to toggle habit: ${error.message}`);
    }
  };
  
  // --- Delete Habit Function ---
  const handleDeleteHabit = async (id) => {
    const { db } = fbServices;
    if (!userId || !db) return;

    console.log(`Deleting habit ${id}`);
    try {
      const habitDocRef = doc(db, `/artifacts/${APP_ID}/users/${userId}/habits`, id);
      await deleteDoc(habitDocRef);
      console.log('Habit deleted successfully.');
    } catch (error) {
      console.error('Error deleting habit:', error);
      showCustomAlert('Database Error', 'Could not delete habit. Please try again.');
    }
  };

  // --- Get AI Habit Suggestion ---
  const getAiSuggestion = async () => {
    if (!aiGoal.trim()) {
      showCustomAlert('Empty Goal', 'Please enter a goal for the AI.');
      return;
    }
    
    // Safety check for local environment key
    if (IS_LOCAL_ENV && LOCAL_GEMINI_API_KEY === "YOUR_GEMINI_API_KEY") {
      showCustomAlert('API Key Required', 'You must replace "YOUR_GEMINI_API_KEY" in App.jsx to run AI features locally.');
      return;
    }

    setLoadingAI(true);
    setAiSuggestion('');

    const systemPrompt = "You are a habit formation expert. Given a user's goal, suggest one simple, actionable daily habit to help them achieve it. The habit should be concise, ideally 5-7 words maximum. Respond with only the habit text, nothing else.";
    
    const payload = {
      contents: [{
        parts: [{ text: `Goal: ${aiGoal}` }]
      }],
      systemInstruction: {
        parts: [{ text: systemPrompt }]
      },
    };

    console.log('Sending request to Gemini API at:', API_URL);
    
    // Exponential backoff retry loop
    const maxRetries = 3;
    let lastError = null;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
          const response = await fetch(API_URL, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload),
          });

          if (!response.ok) {
              const errorBody = await response.text();
              throw new Error(`API request failed with status ${response.status}. Body: ${errorBody}`);
          }

          const result = await response.json();
          // Log the full response for detailed debugging
          console.log('Gemini API response received:', JSON.stringify(result, null, 2));
          
          const candidate = result.candidates?.[0];
          const text = candidate?.content?.parts?.[0]?.text;

          if (text) {
              const cleanText = text.replace(/["']+/g, '').trim();
              setAiSuggestion(cleanText);
              console.log(`AI Suggestion set: ${cleanText}`);
              setLoadingAI(false);
              return; // Success, exit function
          } else {
              // Improved error logging to catch issues like safety blocks
              if (result.promptFeedback?.blockReason) {
                  throw new Error(`Content was blocked by safety filter. Reason: ${result.promptFeedback.blockReason}`);
              }
              if (!candidate) {
                  throw new Error('API returned no candidates. This usually means the content was filtered or an internal error occurred.');
              }
              throw new Error('Invalid or empty text part in API response structure.');
          }
        } catch (error) {
            lastError = error;
            console.error(`Attempt ${attempt + 1} failed:`, error);
            if (attempt < maxRetries - 1) {
                const delay = Math.pow(2, attempt) * 1000;
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }

    // If all attempts fail
    setLoadingAI(false);
    showCustomAlert('AI Error', `Could not get a suggestion after ${maxRetries} attempts. ${lastError?.message || ''}`);
  };

  const showCustomAlert = (title, message) => {
    console.warn(`${title}: ${message}`);
    Alert.alert(title, message);
  };

  // --- Render Habit Item ---
  const renderHabit = ({ item }) => (
    <View style={styles.habitItem}>
      {/* Checkbox and Text Area (Toggleable) */}
      <TouchableOpacity
        onPress={() => toggleHabit(item.id, item.completed)}
        style={styles.checkboxWrapper} 
      >
        <View style={{...styles.checkbox, ...(item.completed ? styles.checkboxCompleted : {})}}>
          {item.completed && <Text style={styles.checkboxCheck}>✓</Text>}
        </View>
        <Text style={{...styles.habitText, ...(item.completed ? styles.habitTextCompleted : {})}}>
          {item.name}
        </Text>
      </TouchableOpacity>

      {/* Delete Button */}
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDeleteHabit(item.id)}
      >
        <Text style={styles.deleteButtonText}>X</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* App Card: Framed, centered content area */}
      <View style={styles.appCard}> 
        {/* Header */}
        <Text style={styles.header}>AI Habit Tracker</Text>
        <Text style={styles.userIdDisplay}>User ID: {userId || 'Authenticating...'}</Text>

        {/* Add Habit Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Add a new habit..."
            value={newHabit}
            onChangeText={setNewHabit}
            placeholderTextColor="#888" 
          />
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => handleAddHabit(newHabit)}
          >
            <Text style={styles.addButtonText}>+</Text>
          </TouchableOpacity>
        </View>

        {/* AI Suggestion Button */}
        <TouchableOpacity
          style={styles.aiButton}
          onPress={() => {
            if (userId && userId !== 'Initialization Failed') {
              setModalVisible(true);
            } else {
              showCustomAlert('Connection Required', 'Please ensure Firebase is correctly initialized.');
            }
          }}
        >
          <Text style={styles.aiButtonText}>💡 Get AI Habit Suggestion</Text>
        </TouchableOpacity>

        {/* Habit List */}
        <FlatList
          data={habits}
          renderItem={renderHabit}
          keyExtractor={(item) => item.id}
          style={styles.list}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No habits yet. Add one!</Text>
            </View>
          }
        />
      </View>
      {/* AI Suggestion Modal (outside appCard as it's fixed position) */}
      <Modal
        visible={modalVisible}
      >
        <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalHeader}>AI Habit Helper</Text>
          <Text style={styles.modalSubHeader}>
            What's your goal? (e.g., "be healthier", "learn code")
          </Text>
          <TextInput
            style={styles.modalInput}
            placeholder="My goal is to..."
            value={aiGoal}
            onChangeText={setAiGoal}
            placeholderTextColor="#888" 
          />
          <TouchableOpacity
            style={styles.modalButton}
            onPress={getAiSuggestion}
            disabled={loadingAI}
          >
            {loadingAI ? (
              <ActivityIndicator />
            ) : (
              <Text style={styles.modalButtonText}>Generate Suggestion</Text>
            )}
          </TouchableOpacity>

          {aiSuggestion && !loadingAI && (
            <View style={styles.suggestionContainer}>
              <Text style={styles.suggestionLabel}>AI Suggestion:</Text>
              <Text style={styles.suggestionText}>{aiSuggestion}</Text>
              <TouchableOpacity
                style={{...styles.modalButton, ...styles.addSuggestionButton}}
                onPress={() => handleAddHabit(aiSuggestion)}
              >
                <Text style={styles.modalButtonText}>Add this habit</Text>
              </TouchableOpacity>
            </View>
          )}

          <TouchableOpacity
            style={{...styles.modalButton, ...styles.closeButton}}
            onPress={() => setModalVisible(false)}
          >
            <Text style={styles.modalButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

// --- Styles (Updated habitItem and habitText for better contrast) ---
const styles = {
  container: {
    minHeight: '100vh', 
    backgroundColor: '#1a1a1a', 
    fontFamily: 'sans-serif',
    color: '#f0f0f0', 
    display: 'flex', 
    flexDirection: 'column', 
    alignItems: 'center', 
    justifyContent: 'center', 
    width: '100%', 
    padding: 0, 
    boxSizing: 'border-box', 
  },
  appCard: { 
    maxWidth: 500, 
    width: '95%', 
    backgroundColor: '#1f1f1f', 
    borderRadius: 20, 
    padding: 30, 
    boxShadow: '0 10px 40px rgba(0, 0, 0, 0.9)', 
    border: '1px solid #3a3a3a', 
    boxSizing: 'border-box',
    margin: '40px 0', 
  },
  header: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#e0e0e0', 
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 10, 
    letterSpacing: 1,
  },
  userIdDisplay: {
    fontSize: 10,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
    wordBreak: 'break-all',
  },
  inputContainer: {
    display: 'flex',
    flexDirection: 'row',
    marginBottom: 20,
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#2c2c2c', 
    padding: '15px 20px',
    borderRadius: 12,
    fontSize: 18,
    color: '#f0f0f0', 
    boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.5)', 
    border: '1px solid #444',
  },
  addButton: {
    marginLeft: 15,
    backgroundColor: '#6200ee', 
    width: 55,
    height: 55,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    boxShadow: '0 4px 8px rgba(0,0,0,0.4)',
    border: 'none',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
  },
  aiButton: {
    backgroundColor: '#03dac6', 
    padding: '18px',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    boxShadow: '0 4px 8px rgba(0,0,0,0.4)',
    marginBottom: 25,
    border: 'none',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
  aiButtonText: {
    color: '#1a1a1a', 
    fontSize: 18,
    fontWeight: '700',
  },
  list: {
    overflowY: 'auto', 
    paddingBottom: 20, 
  },
  habitItem: {
    // *** MODIFIED ***
    backgroundColor: '#242424', // Slightly darker background for better contrast
    padding: 18,
    borderRadius: 12,
    marginBottom: 12,
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
    border: '1px solid #444',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  checkboxWrapper: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start', // Align items to the top (checkbox and text)
    flex: 1,
    paddingRight: 15,
    // --- NEW FIXES: NORMALIZE BUTTON ELEMENT STYLES ---
    backgroundColor: 'transparent',
    padding: 0,
    margin: 0,
    border: 'none',
    textAlign: 'left', // Crucial for button alignment of text
  },
  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 2, 
    borderStyle: 'solid', 
    borderColor: '#6200ee', 
    marginRight: 20,
    justifyContent: 'center',
    alignItems: 'center',
    boxSizing: 'border-box',
    transition: 'background-color 0.2s ease, border-color 0.2s ease',
    // Added flexShrink to prevent the checkbox from shrinking if text is too long
    flexShrink: 0, 
  },
  checkboxCompleted: {
    backgroundColor: '#03dac6', 
    borderColor: '#03dac6',
  },
  checkboxCheck: {
    color: '#1a1a1a', 
    fontSize: 16,
    fontWeight: 'bold',
  },
  habitText: {
    // *** MODIFIED ***
    fontSize: 18,
    color: '#fff', // Pure white text
    flexShrink: 1, // Allows the text to shrink and wrap
    wordBreak: 'break-word', // Ensure long words break properly
    display: 'block', 
    // Ensure no unwanted margin/padding on the text element itself
    margin: 0, 
    padding: 0,
  },
  habitTextCompleted: {
    textDecorationLine: 'line-through',
    color: '#888', 
    fontStyle: 'italic',
  },
  deleteButton: {
    backgroundColor: '#cf6679', 
    width: 35,
    height: 35,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    border: 'none',
    cursor: 'pointer',
    flexShrink: 0,
    marginLeft: 10,
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
  },
  deleteButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyContainer: {
    marginTop: 60,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: '#888',
    fontStyle: 'italic',
  },
  modalContainer: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.75)', 
    zIndex: 1000,
  },
  modalContent: {
    width: '90%',
    maxWidth: 450,
    backgroundColor: '#2c2c2c',
    borderRadius: 15,
    padding: 30,
    alignItems: 'center',
    boxShadow: '0 8px 25px rgba(0,0,0,0.8)',
    border: '1px solid #555',
  },
  modalHeader: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#e0e0e0',
    marginBottom: 15,
  },
  modalSubHeader: {
    fontSize: 15,
    color: '#aaa',
    textAlign: 'center',
    marginBottom: 25,
  },
  modalInput: {
    width: '100%',
    backgroundColor: '#1a1a1a',
    padding: '15px 20px',
    borderRadius: 10,
    fontSize: 17,
    color: '#f0f0f0',
    marginBottom: 25,
    border: '1px solid #6200ee',
    boxSizing: 'border-box',
  },
  modalButton: {
    backgroundColor: '#6200ee',
    width: '100%',
    padding: '16px',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    border: 'none',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '600',
  },
  suggestionContainer: {
    width: '100%',
    marginTop: 25,
    padding: 20,
    backgroundColor: '#3a3a3a',
    borderRadius: 12,
    alignItems: 'center',
    boxSizing: 'border-box',
    border: '1px dashed #03dac6',
  },
  suggestionLabel: {
    fontSize: 15,
    color: '#03dac6',
    marginBottom: 5,
  },
  suggestionText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#e0e0e0',
    marginVertical: 10,
    textAlign: 'center',
  },
  addSuggestionButton: {
    backgroundColor: '#03dac6',
  },
  closeButton: {
    backgroundColor: '#cf6679',
    marginTop: 15,
  },
};
